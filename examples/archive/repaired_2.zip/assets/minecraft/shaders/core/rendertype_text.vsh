#version 150

precision highp float;








#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void f_76cb5fd3(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ebbcdc11() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_439cb9a4(inout vec4 vertex) {
    f_76cb5fd3(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ebbcdc11();
    }
    finalize();
}



void f_82f43ef1() {
    vertexColor=hue(gl_Position.x+GameTime*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_efc71100() {
    gl_Position.y+=sin(GameTime*12000.+(gl_Position.x*6)) / 150.;
}

void f_3d899a85(inout vec4 vertex) {
    f_76cb5fd3(vertex);
    f_82f43ef1();
    finalize();
}

void f_2bc35ce8(inout vec4 vertex) {
    f_76cb5fd3(vertex);
    f_ebbcdc11();
    f_efc71100();
    finalize();
}

void f_4c9d9671(inout vec4 vertex) {
    f_76cb5fd3(vertex);
    f_efc71100();
    f_82f43ef1();
    finalize();
}

void f_b9cdf6a9(inout vec4 vertex) {
    f_ebbcdc11();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(GameTime*12000. / 4)*.1;
            vertex.y+=max(cos(GameTime*12000. / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(GameTime*12000. / 4)*3;
            vertex.y-=max(cos(GameTime*12000. / 4)*4, 0.);
        }
    }
    f_76cb5fd3(vertex);
    finalize();
}

void f_fefd247b(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(GameTime*12000. / 4)*.1;
            vertex.y+=max(cos(GameTime*12000. / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(GameTime*12000. / 4)*3;
            vertex.y-=max(cos(GameTime*12000. / 4)*4, 0.);
        }
    }
    f_82f43ef1();
    f_76cb5fd3(vertex);
    finalize();
}

void f_76aa9c1a(inout vec4 vertex, float speed) {
    f_76cb5fd3(vertex);
    float blink=abs(sin(GameTime*12000.*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_f729d827(inout vec4 vertex) {
    f_76cb5fd3(vertex);
    f_ebbcdc11();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_439cb9a4(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ebbcdc11();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_76cb5fd3(vertex);
            f_ebbcdc11();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_2bc35ce8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_2bc35ce8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_b9cdf6a9(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_b9cdf6a9(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_76aa9c1a(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_f729d827(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_3d899a85(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_2bc35ce8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_4c9d9671(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_b9cdf6a9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_fefd247b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_76aa9c1a(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_3d899a85(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_2bc35ce8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_4c9d9671(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_b9cdf6a9(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_fefd247b(vertex);
        return;
    }
    

    
    f_76cb5fd3(vertex);
    f_ebbcdc11();
    finalize();
}