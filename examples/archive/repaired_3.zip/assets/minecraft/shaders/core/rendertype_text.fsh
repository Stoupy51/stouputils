#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
flat in int trigger;

out vec4 fragColor;

vec3 hue(float t) {
    return clamp(
        abs(mod(t * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0,
        0.0, 1.0
    );
}

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    if (tex.a < 0.1) discard;

    vec4 color;
    if (trigger == 8) {
        float scroll = -(GameTime * 500.0);
        float spatial = (gl_FragCoord.x + gl_FragCoord.y) * 0.005;
        vec3 rainbow = hue(scroll + spatial) * 0.75;
        color = vec4(rainbow * tex.rgb, tex.a * vertexColor.a);
    } else if (trigger == 7) {
        float scroll = -(GameTime * 5000.0);
        float spatial = (gl_FragCoord.x + gl_FragCoord.y) * 0.02;
        float stripe = step(0.5, fract((spatial + scroll) / 6.28318));
        vec3 color1 = vec3(10.0/255.0, 10.0/255.0, 10.0/255.0);
        vec3 color2 = vec3(20.0/255.0, 20.0/255.0, 20.0/255.0);
        vec3 stripeColor = mix(color2, color1, stripe);
        color = vec4(stripeColor * tex.rgb, tex.a * vertexColor.a);
    } else if (trigger == 10) {
        float fill = vertexColor.b + 0.03;
        float filled = step(texCoord0.x, fill);

        vec4 green = vec4(0.2, 0.8, 0.2, 1.0);
        vec4 red   = vec4(0.8, 0.2, 0.2, 1.0);

        float rNorm = color.r / 255.0;
        float isRed = step(0.5, vertexColor.r);

        vec4 filledColor = mix(green, red, isRed);

        vec4 emptyColor = vec4(0.0, 0.0, 0.0, 0.35);
        color = mix(emptyColor, filledColor, filled);
    } else { color = tex * vertexColor; }

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}