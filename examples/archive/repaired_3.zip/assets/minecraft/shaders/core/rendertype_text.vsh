#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out int trigger;

void main() {
    vec3 pos = Position;
    vec4 color = Color;
    int id = 0;
    bool anchored = false;

    if (pos.y >= 34000.0) {
        pos.y -= 34000.0;
        color.a = 1.0;
        id = 13;
    } else if (pos.y >= 33000.0) {
        pos.y -= 33000.0;
        color.a = 1.0;
        id = 12;
    } else if (pos.y >= 32000.0) {
        pos.y -= 32000.0;
        color.a = 1.0;
        id = 11;
    } else if (pos.y >= 31000.0) {
        pos.y -= 31000.0;
        color.a = 1.0;
        id = 10;
    } else if (pos.y >= 30000.0) {
        pos.y -= 30000.0;
        color.a = 1.0;
        id = 9;
    } else if (distance(color.rgb, vec3(133.0/255.0, 93.0/255.0, 50.0/255.0)) < 0.01) {
        id = 8;
    } else if (distance(color.rgb, vec3(108.0/255.0, 133.0/255.0, 50.0/255.0)) < 0.01) {
        id = 7;
    }

    else if (pos.y >= 29000.0) {
        pos.y -= 29000.0;
        color.a = 1.0;
        id = 6;
    }

    else if (pos.y >= 10000.0) {
        pos.y -= 10000.0;
        color.a = 1.0;
        id = 5;
    }

    else if (pos.y >= 5000.0) {
        pos.y -= 5000.0;
        color.a = 1.0;
        id = 4;
    } else if (pos.y >= 4000.0) {
        pos.y -= 4000.0;
        color.a = 1.0;
        id = 3;
    } else if (pos.y >= 3000.0) {
        pos.y -= 3000.0;
        color.a = 1.0;
        id = 2;
    } else if (pos.y >= 2000.0) {
        pos.y -= 2000.0;
        color.a = 1.0;
        id = 1;
    }

    vec4 worldPos = ModelViewMat * vec4(pos, 1.0);
    gl_Position = ProjMat * worldPos;

    float x = 16.0;
    float y = 6.0;

    if (id == 1) {
        // top left
        float halfTextWidthClip = (0.0 / ScreenSize.x) * gl_Position.w * 2.0;
        float nudgeX = x / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = y / ScreenSize.y * 2.0 * gl_Position.w;

        gl_Position.x -= gl_Position.w;
        gl_Position.x += halfTextWidthClip;
        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    } else if (id == 2) {
        // top right
        float halfTextWidthClip = (0.0 / ScreenSize.x) * gl_Position.w * 2.0;
        float offsetY = 38.0;
        float nudgeX = x / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = (y + offsetY) / ScreenSize.y * 2.0 * gl_Position.w;

        gl_Position.x += gl_Position.w;
        gl_Position.x -= halfTextWidthClip;
        gl_Position.x -= nudgeX;
        gl_Position.y += nudgeY;

        vec2 anchor = vec2(gl_Position.w, gl_Position.w);
        gl_Position.xy = anchor + (gl_Position.xy - anchor) * 3.0;
    } else if (id == 3) {
        // bottom left
        float halfTextWidthClip = (0.0 / ScreenSize.x) * gl_Position.w * 2.0;
        float nudgeX = x / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeYUp = y / ScreenSize.y * 2.0 * gl_Position.w;
        float nudgeYDown = (97.0 / 100.0) * 2.0 * gl_Position.w;

        gl_Position.x -= gl_Position.w;
        gl_Position.x += halfTextWidthClip;
        gl_Position.x += nudgeX;
        gl_Position.y += nudgeYUp;
        gl_Position.y -= nudgeYDown;
    } else if (id == 4) {
        // bottom right
        float halfTextWidthClip = (0.0 / ScreenSize.x) * gl_Position.w * 2.0;
        float nudgeX = x / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeYUp = y / ScreenSize.y * 2.0 * gl_Position.w;
        float t = clamp((ScreenSize.y - 480.0) / (1440.0 - 480.0), 0.0, 1.0);
        float screenFraction = mix(0.91, 0.97, t);
        float nudgeYDown = screenFraction * 2.0 * gl_Position.w;

        gl_Position.x += gl_Position.w;
        gl_Position.x -= halfTextWidthClip;
        gl_Position.x -= nudgeX;
        gl_Position.y += nudgeYUp;
        gl_Position.y -= nudgeYDown;

        vec2 anchor = vec2(gl_Position.w, -gl_Position.w);
        gl_Position.xy = anchor + (gl_Position.xy - anchor) * 2.0;
    }

    else if (id == 5) {
        // menu
        float nudgeX = -16.0 / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = 0.0 / ScreenSize.y * 2.0 * gl_Position.w;

        color = vec4(1.0, 1.0, 1.0, 1.0);

        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    }

    else if (id == 6) {
        float nudgeX = 0.0 / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = 84.0 / ScreenSize.y * 2.0 * gl_Position.w;

        color = vec4(color.r, color.g, color.b, 0.25);

        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    }

    else if (id == 7) {
        color = vec4(1.0, 0.0, 0.0, color.a);
        gl_Position.xy *= 2.0;
    }

    else if (id == 9) {
        float nudgeX = 0.0 / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = 104.0 / ScreenSize.y * 2.0 * gl_Position.w;

        color = vec4(color.r, color.g, color.b, 0.25);

        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    }

    else if (id == 10) {
        float nudgeX = 0.0 / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = -80.0 / ScreenSize.y * 2.0 * gl_Position.w;

        color = vec4(color.r, 0.0, color.b, 1.0);

        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    }

    else if (id == 12) {
        float nudgeX = -502.0 / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = -87.0 / ScreenSize.y * 2.0 * gl_Position.w;

        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    }

    else if (id == 11) {
        float nudgeX = 0.0 / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = -50.0 / ScreenSize.y * 2.0 * gl_Position.w;

        color = vec4(0.0, 0.0, 0.0, 0.35);

        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    }

    else if (id == 13) {
        float nudgeX = -502.0 / ScreenSize.x * 2.0 * gl_Position.w;
        float nudgeY = -57.0 / ScreenSize.y * 2.0 * gl_Position.w;

        gl_Position.x += nudgeX;
        gl_Position.y += nudgeY;
    }

    trigger = id;
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}