#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

void main() {
    vec4 standardViewPos = ModelViewMat * vec4(Position, 1.0);

    float Y_UP_THRESHOLD = 2.25;
    float X_THRESHOLD = 1.5;
    float Z_THRESHOLD = 1.5;

    bool inRange = standardViewPos.y < Y_UP_THRESHOLD
        && abs(standardViewPos.x) < X_THRESHOLD
        && abs(standardViewPos.z) < Z_THRESHOLD;

    float SCALE = 0.60;
    float FORWARD = 0.18;
    float RIGHT_OFFSET = 0.13;
    float DOWN_OFFSET  = 0.60;

    if (inRange) {
        vec3 viewPos = vec3(
            -Position.x * SCALE + RIGHT_OFFSET,
            (Position.y - DOWN_OFFSET) * SCALE,
            -FORWARD + (-Position.z * SCALE)
        );

        gl_Position = ProjMat * vec4(viewPos, 1.0);
        gl_Position.z = mix(-gl_Position.w, gl_Position.w, (gl_Position.z / gl_Position.w) * 0.5 + 0.5) * 0.01;
    } else { gl_Position = ProjMat * standardViewPos; }

    vec3 correctedNormal = normalize(mat3(ModelViewMat) * vec3(-Normal.x, Normal.y, Normal.z));

    sphericalVertexDistance = length(standardViewPos.xyz);
    cylindricalVertexDistance = length(standardViewPos.xz);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, correctedNormal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
}